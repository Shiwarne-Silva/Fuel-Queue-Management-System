module com.example.task_4_gui_final {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.task_4_gui_final to javafx.fxml;
    exports com.example.task_4_gui_final;
}